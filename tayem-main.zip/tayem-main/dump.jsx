import React from "react";
import Layout from "../layout";
import Router from "next/router";
import "../assets/sass/app.scss";
import store from "../context/store";
import { Provider } from "react-redux";
import { Loader, View } from "../@fastor";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function MyApp({ Component, pageProps }) {
  const [loading, setLoading] = React.useState(false);

  function PageLoad() {
    React.useEffect(() => {
      Router.events.on("routeChangeStart", () => {
        return setLoading(true);
      });

      Router.events.on("routeChangeComplete", () => {
        return setLoading(false);
      });
    }, []);

    return (
      loading && (
        <View
          ht="100vh"
          pos="fxd"
          top={0}
          zx={1999}
          posx="center"
          posv="center"
          backdrop="mirror"
        >
          <Loader />
        </View>
      )
    );
  }

  return (
    <Provider store={store}>
      <PageLoad />
      <Layout>
        <Component {...pageProps} />
      </Layout>
      <ToastContainer />
    </Provider>
  );
}

export default MyApp;
