import React from 'react'
import Lander from './Lander'
import Invitation from './Invitation'
import Proposal from '../../components/Proposal'


export default function Home({ stories }){
    const id = "34ab5151-5227-4905-84d9-51ebbf685df5"
    
    return (
        <React.Fragment>
            <Lander stories={stories} />
            <Invitation />
        </React.Fragment>
    )
}

