export { Loader } from './Loader'
export { Spinner } from './Spinner'
export { RingLoader } from './Ring'
export { Roller } from "./Roller"
export { DotLoader } from "./Dots"