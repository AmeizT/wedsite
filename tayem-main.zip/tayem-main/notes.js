https://www.alibaba.com/product-detail/double-breasted-slim-fit-dark-green_62389419095.html
https://www.alibaba.com/product-detail/Floor-Length-Formal-Wedding-Party-Bridesmaid_1600508122591.html



import { v4 as uuid } from 'uuid'
import InfoCard from "./InfoCard"
import InfoSection from './InfoSection'
import { Box, Segment } from "../../@fastor"

export default function Info({ food, gifts, venue, program, instructions, dressCode, theme }){
    return (
        <Box $dir="vrt" space="var(--h30) var(--s10) var(--s10)">
            <InfoSection title="Venue">
                <InfoCard info={venue} />
            </InfoSection>

            <InfoSection title="Wedding Program">
                {program.length > 0 && <InfoCard info={program} />}
            </InfoSection>

            <InfoSection title="Food Menu">
                {food.length > 0 && <InfoCard info={food} />}
            </InfoSection>

            <InfoSection title="Dress Code for Guests">
                {dressCode.length > 0 && <InfoCard info={dressCode} />}
            </InfoSection>

            <InfoSection title="Wedding Theme">
                {theme.length > 0 && <InfoCard info={theme} />}
            </InfoSection>

            <InfoSection title="Gifts">
                {gifts.length > 0 && <InfoCard info={gifts} />}
            </InfoSection>

            <InfoSection title="Notes">
                {instructions.length > 0 && <InfoCard info={instructions} />}
            </InfoSection>
        </Box>
    )
}

Info.defaultProps = {
    program: [
        { id: uuid(), name: '13.00 - 14.30', description: 'Guests arrival + opening music' },
        { id: uuid(), name: '14.30 - 15.00', description: 'Church service/ceremony' },
        { id: uuid(), name: '15.00 - 15.30', description: 'Bridal team entrance' },
        { id: uuid(), name: '15.30 - 16.00', description: 'Cocktail + music' },
        { id: uuid(), name: '16.00 - 16.30', description: 'Bridal entrance' },
        { id: uuid(), name: '16.30 - 16.45', description: 'Bridal Games' },
        { id: uuid(), name: '16.45 - 17.30', description: 'Main meal' },
        { id: uuid(), name: '17.30 - 17.45', description: 'Speeches' },
        { id: uuid(), name: '17.45 - 18.00', description: 'Cake cutting' },
        { id: uuid(), name: '18.00 - 18.30', description: 'Music, dancing, closing remarks' },
    ],

    venue: [{id: uuid(), name: 'Blue Ridge Farm, Goromonzi', description: ''}],

    food: [
        { id: uuid(), name: 'Grilled Chicken', description: '' },
        { id: uuid(), name: 'Wors', description: '' },
        { id: uuid(), name: 'Seswa', description: '' },
        { id: uuid(), name: 'Pork', description: '' },
        { id: uuid(), name: 'Sadza', description: '' },
        { id: uuid(), name: 'Fried Rice', description: '' },
        { id: uuid(), name: 'Tuna Malt Pasta', description: '' },
        { id: uuid(), name: 'Creamy smoked butternut mash', description: '' },
        { id: uuid(), name: 'Chakalaka bean & veggie', description: '' },
        { id: uuid(), name: 'Fried veggies', description: '' },
        { id: uuid(), name: 'Coleslaw', description: '' },
    ],

    dressCode: [
        { id: uuid(), name: 'Semi-formal', description: 'Wedges, or formal flats. Dress shirt and slacks for men with the option to wear a tie.' },
        { id: uuid(), name: 'Smart Casual', description: 'Summer sundress, wedges and dressy sandals.' },
        { id: uuid(), name: 'Festive', description: 'Women should wear a cocktail dress or party dress in a fun color paired with playful accessories and heels or dressy flats. Men should sport a suit, jazzed up with a bright tie or creative pocket square.' },
    ],

    theme: [{id: uuid(), name: 'Rustic/Vintage Wedding', description: 'Any shade of green, brown and gold. Dress code should at least resemble vintage/retro fashion. Creative ankara is also acceptable.'}],

    gifts: [{id: uuid(), name: 'Your presence at our wedding is the greatest gift of all. However, if you wish to honour us with a gift, a cash gift would be welcome but not expected.', description: 'Since the newly-weds do not live in Zimbabwe, entry may be restricted for gifts other than cash. Cash gift envelopes will be available at the entrance.'}],

    instructions: [
        { id: uuid(), description: 'Attendance is strictly by invitation due to the limited sitting space at the venue.' },

        { id: uuid(), description: 'Be sure to sign and write a short message for the bride & groom in our guest book that will be placed at the entrance. (This is not mandatory but it would mean the world to us.)' },

        { id: uuid(), description: 'Kindly search for your name on the seating chart to confirm your table and seat number.' },

        { id: uuid(), description: 'Feel free to indulge yourselves with delicious treats & cocktails on the grazing table soon after the church service/ceremony.' },

        { id: uuid(), description: '"Strictly no children" rule should also be observed at our wedding due to the limited space at the venue. However, feeding moms are exempted.' },

        { id: uuid(), description: 'Outside toilets will be available at the venue.' },

        { id: uuid(), description: 'If you have any special dietary requests, tap on any of the contact buttons so that we can inform the chef.' },
    ],
}